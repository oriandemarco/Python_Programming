# File:    PersonalDataOrianDemarco.py 
# Project: CSIS2101 Assignment 1
# Author:  Orian Demarco
# History: Version 1.1 September 4, 2023
# Program: Printing my personal data.

#  1) Name:
print("Name: Orian Demarco")

#  2) Email address:
print("Email address: od199@mynsu.nova.edu")

#  3) Major:
print("Major: Information Technology")


#  4) Minor: ( if any, if none put N/A )
print("Minor: Data Analytics, Graphic Design, Psychology, Honors Transdisciplinary Studies")


# 5) Campus dorm or town where you now live:
print("Campus dorm or town where you now live: On campus in Mako Hall and with local family.")


# 6) Hometown or country where you grew up:
print("Hometown or country where you grew up: I grew up in Mars Pennsylvania but have been local for about 10 years.")


# 7) Any Programming languages with which you have even a little experience:
print("Any Programming languages with which you have even a little experience: Python, JavaScript, HTML, CSS")


# 8) Favorite Movie or TV show you like to watch:
print("Favorite Movie or TV show you like to watch: Better Call Saul")


# 9) Favorite Anime:
print("Favorite Anime: Attack on Titan")


# 10) Favorite Sport or Hobby: 
print("Favorite Sport or Hobby: My favorite sport is Basketball.")


# 11) Favorite Restaurant:
print("Favorite Restaurant: Toojays")




