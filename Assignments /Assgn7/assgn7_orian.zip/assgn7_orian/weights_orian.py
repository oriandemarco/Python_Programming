# File:    weights_orian.py 
# Project: CSIS2101 Assignment 7
# Author:  Orian Demarco 
# History: Version 1.3 October 23, 2023
# Program: Calculate Planet Weights.


G_MOON = 1.62
G_EARTH = 9.81
G_MARS = 3.77
G_SATURN = 10.39
# Constants for gravitational force on each planet

def weight_moon_orian(kg_mass):
    return kg_mass * G_MOON
# Function to calculate weight on Moon, multiplies mass in kg by earth's gravity constant. 

def weight_earth_orian(kg_mass):
    return kg_mass * G_EARTH
# Function to calculate weight on Earth, multiplies mass in kg by earth's gravity constant. 

def weight_mars_orian(kg_mass):
    return kg_mass * G_MARS
# Function to calculate weight on Mars,  multiplies mass in kg by earth's gravity constant. 

def weight_saturn_orian(kg_mass):
    return kg_mass * G_SATURN
# Function to calculate weight on Saturn, multiplies mass in kg by earth's gravity constant. 